pluginManagement {
	repositories {
		gradlePluginPortal()
	}
}
rootProject.name = "apiness"
